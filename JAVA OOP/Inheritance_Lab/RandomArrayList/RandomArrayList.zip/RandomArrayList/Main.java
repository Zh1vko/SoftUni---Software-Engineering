package RandomArrayList;

public class Main {
    public static void main(String[] args) {
            RandomArrayList arr = new RandomArrayList();
            arr.add(5);
            arr.add(7);
            arr.add(2111);
            arr.add(27);
            arr.add(12);

        System.out.println(arr.getRandomElement());
        System.out.println(arr.getRandomElement());
        System.out.println(arr.getRandomElement());
        System.out.println(arr.getRandomElement());
        System.out.println(arr.getRandomElement());
    }
}
