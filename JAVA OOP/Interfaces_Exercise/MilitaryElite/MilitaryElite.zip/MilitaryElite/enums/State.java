package MilitaryElite.Enums;

public enum State {
    inProgress,
    finished

}
