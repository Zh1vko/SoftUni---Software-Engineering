package MilitaryElite.Enums;

public enum Corp {
    Airforces,
    Marines
}
