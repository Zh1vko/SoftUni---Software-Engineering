package MilitaryElite.enums;

public enum MissionState {
    inProgress,
    finished
}
