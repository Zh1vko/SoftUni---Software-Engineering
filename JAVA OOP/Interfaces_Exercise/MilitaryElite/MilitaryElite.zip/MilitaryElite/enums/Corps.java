package MilitaryElite.enums;

public enum Corps {
    Airforces,
    Marines
}
