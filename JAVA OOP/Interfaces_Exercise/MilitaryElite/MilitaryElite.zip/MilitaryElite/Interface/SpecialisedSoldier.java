package MilitaryElite.Interface;

import MilitaryElite.Enums.Corp;

public interface SpecialisedSoldier {

    Corp getCorps();
}
