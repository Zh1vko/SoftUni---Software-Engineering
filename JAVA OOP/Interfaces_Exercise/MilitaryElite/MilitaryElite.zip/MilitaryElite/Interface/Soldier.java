package MilitaryElite.Interface;

public interface Soldier {
    int getId();
    String getFirstName();
    String getLastName();

}
