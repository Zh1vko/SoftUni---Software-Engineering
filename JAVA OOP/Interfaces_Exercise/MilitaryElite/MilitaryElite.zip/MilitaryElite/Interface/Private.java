package MilitaryElite.Interface;

public interface Private {
    double getSalary();
}
