package MilitaryElite.Interface;

import MilitaryElite.entities.PrivateImpl;

public interface LieutenantGeneral {
    void addPrivate(PrivateImpl priv);
}
