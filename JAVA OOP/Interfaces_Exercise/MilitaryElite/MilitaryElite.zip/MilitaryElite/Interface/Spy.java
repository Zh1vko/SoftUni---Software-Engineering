package MilitaryElite.Interface;

public interface Spy {
    String getCodeNumber();

}
