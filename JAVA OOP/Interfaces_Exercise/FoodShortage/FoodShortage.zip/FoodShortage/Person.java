package FoodShortage;

public interface Person {

    String getName();
    int getAge();

}
