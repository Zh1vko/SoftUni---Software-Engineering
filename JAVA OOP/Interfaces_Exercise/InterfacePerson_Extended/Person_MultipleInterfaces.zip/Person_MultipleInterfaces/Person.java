package InterfacePerson_MultipleInterfaces;

public interface Person {

    String getName();
    int getAge();

}
