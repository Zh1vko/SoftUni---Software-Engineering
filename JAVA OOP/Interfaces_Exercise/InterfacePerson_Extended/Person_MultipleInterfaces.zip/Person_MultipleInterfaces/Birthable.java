package InterfacePerson_MultipleInterfaces;

public interface Birthable {

    String getBirthDate();
}
