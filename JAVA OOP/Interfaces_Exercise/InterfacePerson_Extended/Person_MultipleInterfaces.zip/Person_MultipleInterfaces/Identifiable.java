package InterfacePerson_MultipleInterfaces;

public interface Identifiable {

    String getId();
}
