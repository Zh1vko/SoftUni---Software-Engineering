package Ferrari;

public class Main {
    public static void main(String[] args) {

        Ferrari newFerrari = new Ferrari("Brian O'Conner");
        System.out.println(newFerrari);
    }
}
