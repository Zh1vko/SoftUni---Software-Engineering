package hero;

public class Main {
    public static void main(String[] args) {


        SoulMaster sm = new SoulMaster("Zhivko", 400);
        System.out.println(sm);
    }
}
